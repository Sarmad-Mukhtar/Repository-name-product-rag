import json


def lambda_handler(event, context):
    question = event.get("question", "")

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Chatbot2 Lambda is working",
            "question": question,
        }),
    }
